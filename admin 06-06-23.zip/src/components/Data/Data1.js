export const Studentdata = [{
        id: 1,
        date: "30/01/2023",
        time: "Last 14hr",
        Question: " What is the intrinsic carrier concenration for germanium at 300k (band gap =0.70ev)?",
        Answer: "As far as I know the various semiconductors you mention are preferred for these features Silicon-Low cost, high breakdown voltage, low leak current. Germanium-Low dropout voltage. But Silicon-metal structures (‘Schottky’) offer a low drop-out as well thus are generally preferred.Gallium Arsenide High speed, high frequency application.   Gallium Nitride High efficiency power applications, hi speed.",
        subject: "Maths",
        type: "MCQ",
    },
    {
        id: 2,
        date: "30/01/2023",
        time: "Last 14hr",
        Question: " What is the intrinsic carrier concenration for germanium at 300k (band gap =0.70ev)?",
        Answer: "As far as I know the various semiconductors you mention are preferred for these features Silicon-Low cost, high breakdown voltage, low leak current. Germanium-Low dropout voltage. But Silicon-metal structures (‘Schottky’) offer a low drop-out as well thus are generally preferred.Gallium Arsenide High speed, high frequency application.   Gallium Nitride High efficiency power applications, hi speed.",
        subject: "Maths",
        type: "Question type",
    },
    {
        id: 3,
        date: "30/01/2023",
        time: "Last 14hr",
        Question: " What is the intrinsic carrier concenration for germanium at 300k (band gap =0.70ev)?",
        Answer: "As far as I know the various semiconductors you mention are preferred for these features Silicon-Low cost, high breakdown voltage, low leak current. Germanium-Low dropout voltage. But Silicon-metal structures (‘Schottky’) offer a low drop-out as well thus are generally preferred.Gallium Arsenide High speed, high frequency application.   Gallium Nitride High efficiency power applications, hi speed.",
        subject: "Maths",
        type: "Question type",
    },
    {
        id: 4,
        date: "30/01/2023",
        time: "Last 14hr",
        Question: " What is the intrinsic carrier concenration for germanium at 300k (band gap =0.70ev)?",
        Answer: "As far as I know the various semiconductors you mention are preferred for these features Silicon-Low cost, high breakdown voltage, low leak current. Germanium-Low dropout voltage. But Silicon-metal structures (‘Schottky’) offer a low drop-out as well thus are generally preferred.Gallium Arsenide High speed, high frequency application.   Gallium Nitride High efficiency power applications, hi speed.",
        subject: "Maths",
        type: "Question type",
    },
    {
        id: 5,
        date: "30/01/2023",
        time: "Last 14hr",
        Question: " What is the intrinsic carrier concenration for germanium at 300k (band gap =0.70ev)?",
        Answer: "As far as I know the various semiconductors you mention are preferred for these features Silicon-Low cost, high breakdown voltage, low leak current. Germanium-Low dropout voltage. But Silicon-metal structures (‘Schottky’) offer a low drop-out as well thus are generally preferred.Gallium Arsenide High speed, high frequency application.   Gallium Nitride High efficiency power applications, hi speed.",
        subject: "Maths",
        type: "Question type",
    },
    {
        id: 6,
        date: "30/01/2023",
        time: "Last 14hr",
        Question: " What is the intrinsic carrier concenration for germanium at 300k (band gap =0.70ev)?",
        Answer: "As far as I know the various semiconductors you mention are preferred for these features Silicon-Low cost, high breakdown voltage, low leak current. Germanium-Low dropout voltage. But Silicon-metal structures (‘Schottky’) offer a low drop-out as well thus are generally preferred.Gallium Arsenide High speed, high frequency application.   Gallium Nitride High efficiency power applications, hi speed.",
        subject: "Maths",
        type: "Question type",
    },
];

export const Posts = [{
        id: 1,
        Question: "What exactly do you know about JavaScript?",
        Answer: "It is basically an object-oriented programming language that is having a lot of applications. It can be used for both server-side, as well as client-side scripting and the good thing is it is known to provide the best results in every aspect. When it comes to building HTML WebPages, this language is often considered and is known to bring the most desired outcomes.",
        student: "Sohan..",
    },

    {
        id: 2,
        Question: " On a client machine, how you will detect the server using JavaScript?",
        Answer: "For this, task, the users can simply proceed with the navigator.app string. The string performs this task automatically and the user just needs to define it at the right time. Also, the users need to make sure that the instructions are executed in the right manner. Sometimes there is a need to define the IP or other address of the server that needs to be detected. ",
        student: "Sohan..",
    },
    {
        id: 3,
        Question: "What according to you is the true difference between Java and JavaScript?",
        Answer: "Well, there are a few differences that separate both these terms from each other.Basically, JavaScript is a modified version or a coded version that is generally considered in the HTML pages while on the other side, Java is a well- known programming language used to develop applications in almost every category.Both these languages don’t depend on each other for their task and have separate applications.Generally, Java is considered an an OOPS language while JavaScript is a scripting language preferred by the clients.Also, JavaScript has wide applications in HTML WebPages while Java is used mostly in developing computer applications.",
        student: "Sohan..",
    },

    {
        id: 4,
        Question: " If the argument is not a number, which function you will use in JavaScript?",
        Answer: " isNan function is useful in case the argument is not a number. Actually, it remains true if the argument doesn’t have a number while on the other side it remains false if it is.",
        student: "Sohan..",
    },

    {
        id: 5,
        Question: " Compare ASP Script and JavaScript in terms of speed ?",
        Answer: " When it comes to speed, both of them are powerful but both have their own limits that put them separate from one another. JavaScript is known to have a quick speed for performing similar functions. This is because JavaScript doesn’t need the help of a web server to perform the task which is assigned to it. However, ASP is slow as compared to it. This is because of the very same reason and i.e. it depends largely on the webserver for executing the tasks assigned to it. Although the server-side version of JavaScript i.e. node.js also exists, still it is known to provide quick results.",
        student: "Sohan..",
    },

    {
        id: 6,
        Question: " In JavaScript, which method you will find similar to the pop method? ",
        Answer: "  TThe Pop method is very much similar to the shift method but there are some noticeable differences. In the pop method, the last element of the defined array is taken generally, and then the same is returned. This often cut down the size of the array. On the other side, the Shift method generally considers the first element of the array or any other element in the beginning. ",
        student: "Sohan..",
    },

    {
        id: 7,
        Question: "How can you break the JavaScript code into different lines?",
        Answer: "This can be done with the help of a backlash. However, you need to use it at the end of the initial line otherwise it will show an error at the end. The good thing is there is no limit on lines that can be created for the purpose of accommodating data. Also, doing this is not at all a big deal and one can easily handle this task.",
    },
    {
        id: 8,
        Question: "Tell something about the undeclared and undefined variables?",
        Answer: "Basically, there are a lot of programs that actually don’t exist in a program and are thus known as undeclared ones.There is always a runtime error displayed on the screen in case the program proceeds with reading the value of a variable that is not declared.On the other side, declared variables as the name indicates are those which are well defined within a program but haven’t been assigned any value by the operator.The value is always returned in case of the program proceeds with reading them.",
        student: "Sohan..",
    },
    {
        id: 9,
        Question: " Are you familiar with the concept of negative infinity in JavaScript?",
        Answer: "Yes, it is actually a number present in this language and can simply be derived by dividing any number having a negative value with zero. There are basically some important applications of negative infinity in JavaScript.",
        student: "Sohan..",
    },
    {
        id: 10,
        Question: " What exactly do you know about the global variables? Which keyword do you use to declare them?",
        Answer: " There are variables in the language that generally doesn’t have much scope or their scope is limited. In JavaScript, Global variables are the same variables. To declare them, the keyword that can be used is var. the fact is most of the programmers avoid using this variable due to a major issue and i.e. the strong chances of clashing of variable names with the global, or with the local group. F course, it leads to many issues. In addition to this, there are certain chances of debugging issues that declare their presence with the global variables.",
        student: "Sohan..",
    },
    {
        id: 11,
        Question: "What exactly do you know about JavaScript?",
        Answer: "It is basically an object-oriented programming language that is having a lot of applications. It can be used for both server-side, as well as client-side scripting and the good thing is it is known to provide the best results in every aspect. When it comes to building HTML WebPages, this language is often considered and is known to bring the most desired outcomes.",
        student: "Sohan..",
    },

    {
        id: 12,
        Question: " On a client machine, how you will detect the server using JavaScript?",
        Answer: "For this, task, the users can simply proceed with the navigator.app string. The string performs this task automatically and the user just needs to define it at the right time. Also, the users need to make sure that the instructions are executed in the right manner. Sometimes there is a need to define the IP or other address of the server that needs to be detected. ",
        student: "Sohan..",
    },
    {
        id: 13,
        Question: "What according to you is the true difference between Java and JavaScript?",
        Answer: "Well, there are a few differences that separate both these terms from each other.Basically, JavaScript is a modified version or a coded version that is generally considered in the HTML pages while on the other side, Java is a well- known programming language used to develop applications in almost every category.Both these languages don’t depend on each other for their task and have separate applications.Generally, Java is considered an an OOPS language while JavaScript is a scripting language preferred by the clients.Also, JavaScript has wide applications in HTML WebPages while Java is used mostly in developing computer applications.",
        student: "Sohan..",
    },

    {
        id: 14,
        Question: " If the argument is not a number, which function you will use in JavaScript?",
        Answer: " isNan function is useful in case the argument is not a number. Actually, it remains true if the argument doesn’t have a number while on the other side it remains false if it is.",
        student: "Sohan..",
    },

    {
        id: 15,
        Question: " Compare ASP Script and JavaScript in terms of speed ?",
        Answer: " When it comes to speed, both of them are powerful but both have their own limits that put them separate from one another. JavaScript is known to have a quick speed for performing similar functions. This is because JavaScript doesn’t need the help of a web server to perform the task which is assigned to it. However, ASP is slow as compared to it. This is because of the very same reason and i.e. it depends largely on the webserver for executing the tasks assigned to it. Although the server-side version of JavaScript i.e. node.js also exists, still it is known to provide quick results.",
        student: "Sohan..",
    },

    {
        id: 16,
        Question: " In JavaScript, which method you will find similar to the pop method? ",
        Answer: "  TThe Pop method is very much similar to the shift method but there are some noticeable differences. In the pop method, the last element of the defined array is taken generally, and then the same is returned. This often cut down the size of the array. On the other side, the Shift method generally considers the first element of the array or any other element in the beginning. ",
        student: "Sohan..",
    },

    {
        id: 17,
        Question: "How can you break the JavaScript code into different lines?",
        Answer: "This can be done with the help of a backlash. However, you need to use it at the end of the initial line otherwise it will show an error at the end. The good thing is there is no limit on lines that can be created for the purpose of accommodating data. Also, doing this is not at all a big deal and one can easily handle this task.",
        student: "Sohan..",
    },
    {
        id: 18,
        Question: "Tell something about the undeclared and undefined variables?",
        Answer: "Basically, there are a lot of programs that actually don’t exist in a program and are thus known as undeclared ones.There is always a runtime error displayed on the screen in case the program proceeds with reading the value of a variable that is not declared.On the other side, declared variables as the name indicates are those which are well defined within a program but haven’t been assigned any value by the operator.The value is always returned in case of the program proceeds with reading them.",
        student: "Sohan..",
    },
    {
        id: 19,
        Question: " Are you familiar with the concept of negative infinity in JavaScript?",
        Answer: "Yes, it is actually a number present in this language and can simply be derived by dividing any number having a negative value with zero. There are basically some important applications of negative infinity in JavaScript.",
        student: "Sohan..",
    },
    {
        id: 20,
        Question: " What exactly do you know about the global variables? Which keyword do you use to declare them?",
        Answer: " There are variables in the language that generally doesn’t have much scope or their scope is limited. In JavaScript, Global variables are the same variables. To declare them, the keyword that can be used is var. the fact is most of the programmers avoid using this variable due to a major issue and i.e. the strong chances of clashing of variable names with the global, or with the local group. F course, it leads to many issues. In addition to this, there are certain chances of debugging issues that declare their presence with the global variables.",
        student: "Sohan..",
    },
    {
        id: 21,
        Question: "What exactly do you know about JavaScript?",
        Answer: "It is basically an object-oriented programming language that is having a lot of applications. It can be used for both server-side, as well as client-side scripting and the good thing is it is known to provide the best results in every aspect. When it comes to building HTML WebPages, this language is often considered and is known to bring the most desired outcomes.",
        student: "Sohan..",
    },

    {
        id: 22,
        Question: " On a client machine, how you will detect the server using JavaScript?",
        Answer: "For this, task, the users can simply proceed with the navigator.app string. The string performs this task automatically and the user just needs to define it at the right time. Also, the users need to make sure that the instructions are executed in the right manner. Sometimes there is a need to define the IP or other address of the server that needs to be detected. ",
        student: "Sohan..",
    },
    {
        id: 23,
        Question: "What according to you is the true difference between Java and JavaScript?",
        Answer: "Well, there are a few differences that separate both these terms from each other.Basically, JavaScript is a modified version or a coded version that is generally considered in the HTML pages while on the other side, Java is a well- known programming language used to develop applications in almost every category.Both these languages don’t depend on each other for their task and have separate applications.Generally, Java is considered an an OOPS language while JavaScript is a scripting language preferred by the clients.Also, JavaScript has wide applications in HTML WebPages while Java is used mostly in developing computer applications.",
        student: "Sohan..",
    },

    {
        id: 24,
        Question: " If the argument is not a number, which function you will use in JavaScript?",
        Answer: " isNan function is useful in case the argument is not a number. Actually, it remains true if the argument doesn’t have a number while on the other side it remains false if it is.",
        student: "Sohan..",
    },

    {
        id: 25,
        Question: " Compare ASP Script and JavaScript in terms of speed ?",
        Answer: " When it comes to speed, both of them are powerful but both have their own limits that put them separate from one another. JavaScript is known to have a quick speed for performing similar functions. This is because JavaScript doesn’t need the help of a web server to perform the task which is assigned to it. However, ASP is slow as compared to it. This is because of the very same reason and i.e. it depends largely on the webserver for executing the tasks assigned to it. Although the server-side version of JavaScript i.e. node.js also exists, still it is known to provide quick results.",
        student: "Sohan..",
    },

    {
        id: 26,
        Question: " In JavaScript, which method you will find similar to the pop method? ",
        Answer: "  TThe Pop method is very much similar to the shift method but there are some noticeable differences. In the pop method, the last element of the defined array is taken generally, and then the same is returned. This often cut down the size of the array. On the other side, the Shift method generally considers the first element of the array or any other element in the beginning. ",
        student: "Sohan..",
    },

    {
        id: 27,
        Question: "How can you break the JavaScript code into different lines?",
        Answer: "This can be done with the help of a backlash. However, you need to use it at the end of the initial line otherwise it will show an error at the end. The good thing is there is no limit on lines that can be created for the purpose of accommodating data. Also, doing this is not at all a big deal and one can easily handle this task.",
        student: "Sohan..",
    },
    {
        id: 28,
        Question: "Tell something about the undeclared and undefined variables?",
        Answer: "Basically, there are a lot of programs that actually don’t exist in a program and are thus known as undeclared ones.There is always a runtime error displayed on the screen in case the program proceeds with reading the value of a variable that is not declared.On the other side, declared variables as the name indicates are those which are well defined within a program but haven’t been assigned any value by the operator.The value is always returned in case of the program proceeds with reading them.",
        student: "Sohan..",
    },
    {
        id: 29,
        Question: " Are you familiar with the concept of negative infinity in JavaScript?",
        Answer: "Yes, it is actually a number present in this language and can simply be derived by dividing any number having a negative value with zero. There are basically some important applications of negative infinity in JavaScript.",
        student: "Sohan..",
    },
    {
        id: 30,
        Question: " What exactly do you know about the global variables? Which keyword do you use to declare them?",
        Answer: " There are variables in the language that generally doesn’t have much scope or their scope is limited. In JavaScript, Global variables are the same variables. To declare them, the keyword that can be used is var. the fact is most of the programmers avoid using this variable due to a major issue and i.e. the strong chances of clashing of variable names with the global, or with the local group. F course, it leads to many issues. In addition to this, there are certain chances of debugging issues that declare their presence with the global variables.",
        student: "Sohan..",
    },
    {
        id: 31,
        Question: "What exactly do you know about JavaScript?",
        Answer: "It is basically an object-oriented programming language that is having a lot of applications. It can be used for both server-side, as well as client-side scripting and the good thing is it is known to provide the best results in every aspect. When it comes to building HTML WebPages, this language is often considered and is known to bring the most desired outcomes.",
        student: "Sohan..",
    },

    {
        id: 32,
        Question: " On a client machine, how you will detect the server using JavaScript?",
        Answer: "For this, task, the users can simply proceed with the navigator.app string. The string performs this task automatically and the user just needs to define it at the right time. Also, the users need to make sure that the instructions are executed in the right manner. Sometimes there is a need to define the IP or other address of the server that needs to be detected. ",
        student: "Sohan..",
    },
    {
        id: 33,
        Question: "What according to you is the true difference between Java and JavaScript?",
        Answer: "Well, there are a few differences that separate both these terms from each other.Basically, JavaScript is a modified version or a coded version that is generally considered in the HTML pages while on the other side, Java is a well- known programming language used to develop applications in almost every category.Both these languages don’t depend on each other for their task and have separate applications.Generally, Java is considered an an OOPS language while JavaScript is a scripting language preferred by the clients.Also, JavaScript has wide applications in HTML WebPages while Java is used mostly in developing computer applications.",
        student: "Sohan..",
    },

    {
        id: 34,
        Question: " If the argument is not a number, which function you will use in JavaScript?",
        Answer: " isNan function is useful in case the argument is not a number. Actually, it remains true if the argument doesn’t have a number while on the other side it remains false if it is.",
        student: "Sohan..",
    },

    {
        id: 35,
        Question: " Compare ASP Script and JavaScript in terms of speed ?",
        Answer: " When it comes to speed, both of them are powerful but both have their own limits that put them separate from one another. JavaScript is known to have a quick speed for performing similar functions. This is because JavaScript doesn’t need the help of a web server to perform the task which is assigned to it. However, ASP is slow as compared to it. This is because of the very same reason and i.e. it depends largely on the webserver for executing the tasks assigned to it. Although the server-side version of JavaScript i.e. node.js also exists, still it is known to provide quick results.",
        student: "Sohan..",
    },

    {
        id: 36,
        Question: " In JavaScript, which method you will find similar to the pop method? ",
        Answer: "  TThe Pop method is very much similar to the shift method but there are some noticeable differences. In the pop method, the last element of the defined array is taken generally, and then the same is returned. This often cut down the size of the array. On the other side, the Shift method generally considers the first element of the array or any other element in the beginning. ",
        student: "Sohan..",
    },

    {
        id: 37,
        Question: "How can you break the JavaScript code into different lines?",
        Answer: "This can be done with the help of a backlash. However, you need to use it at the end of the initial line otherwise it will show an error at the end. The good thing is there is no limit on lines that can be created for the purpose of accommodating data. Also, doing this is not at all a big deal and one can easily handle this task.",
        student: "Sohan..",
    },
    {
        id: 38,
        Question: "Tell something about the undeclared and undefined variables?",
        Answer: "Basically, there are a lot of programs that actually don’t exist in a program and are thus known as undeclared ones.There is always a runtime error displayed on the screen in case the program proceeds with reading the value of a variable that is not declared.On the other side, declared variables as the name indicates are those which are well defined within a program but haven’t been assigned any value by the operator.The value is always returned in case of the program proceeds with reading them.",
        student: "Sohan..",
    },
    {
        id: 39,
        Question: " Are you familiar with the concept of negative infinity in JavaScript?",
        Answer: "Yes, it is actually a number present in this language and can simply be derived by dividing any number having a negative value with zero. There are basically some important applications of negative infinity in JavaScript.",
        student: "Sohan..",
    },
    {
        id: 40,
        Question: " What exactly do you know about the global variables? Which keyword do you use to declare them?",
        Answer: " There are variables in the language that generally doesn’t have much scope or their scope is limited. In JavaScript, Global variables are the same variables. To declare them, the keyword that can be used is var. the fact is most of the programmers avoid using this variable due to a major issue and i.e. the strong chances of clashing of variable names with the global, or with the local group. F course, it leads to many issues. In addition to this, there are certain chances of debugging issues that declare their presence with the global variables.",
        student: "Sohan..",
    },
];



export const Testimonialdata = [{
        sortorder: 1,
        profileimg: 'https://www.gravatar.com/avatar/205e460b479e2e5b48aec07710c08d50',
        user: 'Eknath Raut',
    },
    {
        sortorder: 2,
        profileimg: 'https://www.gravatar.com/avatar/205e460b479e2e5b48aec07710c08d50',
        user: 'Abernathy Group',
    },
    {
        sortorder: 3,
        profileimg: 'https://www.gravatar.com/avatar/205e460b479e2e5b48aec07710c08d50',
        user: 'Eknath Raut',
    },
    {
        sortorder: 4,
        profileimg: 'https://www.gravatar.com/avatar/205e460b479e2e5b48aec07710c08d50',
        user: 'Eknath Raut',
    },
    {
        sortorder: 5,
        profileimg: 'https://www.gravatar.com/avatar/205e460b479e2e5b48aec07710c08d50',
        user: 'Eknath Raut',
    },
    {
        sortorder: 6,
        profileimg: 'https://www.gravatar.com/avatar/205e460b479e2e5b48aec07710c08d50',
        user: 'Eknath Raut',
    },
    {
        sortorder: 7,
        profileimg: 'https://www.gravatar.com/avatar/205e460b479e2e5b48aec07710c08d50',
        user: 'Clementine Bauch',
    },
    {
        sortorder: 8,
        profileimg: 'https://www.gravatar.com/avatar/205e460b479e2e5b48aec07710c08d50',
        user: 'Kurtis Weissnat',
    },
    {
        sortorder: 9,
        profileimg: 'https://www.gravatar.com/avatar/205e460b479e2e5b48aec07710c08d50',
        user: 'Ellsworth Summit',
    },
    {
        sortorder: 10,
        profileimg: 'https://www.gravatar.com/avatar/205e460b479e2e5b48aec07710c08d50',
        user: 'Ervin Howell',
    }
]


export const TutorList = [{
        id: 1,
        date: '20/02/23',
        username: 'Eknath Raut',
        email: 'eknathraut09@gmail.com',
        mobileNo: '8379882933',
        subject: 'Biology',
        balance: '300',
    },
    {
        id: 2,
        date: '21/02/23',
        username: 'Abernathy Group',
        email: 'Eliseo@gardner.biz',
        mobileNo: '9679882933',
        subject: 'Chemistry',
        balance: '500',
    },
    {
        id: 3,
        date: '12/02/23',
        username: 'Eknath Raut',
        email: 'Jayne_Kuhic@sydney.com',
        mobileNo: '7779882933',
        subject: 'Biology',
        balance: '600',
    },
    {
        id: 4,
        date: '21/02/23',
        username: 'Eknath Raut',
        email: 'Nikita@garfield.biz',
        mobileNo: '9879882933',
        subject: 'Chemistry',
        balance: '600',
    },
    {
        id: 5,
        date: '12/02/23',
        username: 'Eknath Raut',
        email: 'Lew@alysha.tv',
        mobileNo: '8879882933',
        subject: 'Math',
        balance: '700',
    },
    {
        id: 6,
        date: '16/02/23',
        username: 'Eknath Raut',
        email: 'Hayden@althea.biz',
        mobileNo: '9679882933',
        subject: 'Biology',
        balance: '500',
    },
    {
        id: 7,
        date: '18/02/23',
        username: 'Clementine Bauch',
        email: 'Mallory_Kunze@marie.org',
        mobileNo: '7879882933',
        subject: 'Chemistry',
        balance: '400',
    },
    {
        id: 8,
        date: '26/02/23',
        username: 'Kurtis Weissnat',
        email: 'Kariane@jadyn.tv',
        mobileNo: '9879882933',
        subject: 'Physics',
        balance: '700',
    },
    {
        id: 9,
        date: '18/02/23',
        username: 'Ellsworth Summit',
        email: 'Preston_Hudson@blaise.tv',
        mobileNo: '8779882933',
        subject: 'Biology',
        balance: '100',
    },
    {
        id: 10,
        date: '20/02/23',
        username: 'Ervin Howell',
        email: 'eknathraut09@gmail.com',
        mobileNo: '8979882933',
        subject: 'Physics',
        balance: '250',
    }

]



export const StudentList = [{
        id: 1,
        date: '20/02/23',
        username: 'Eknath Raut',
        email: 'eknathraut09@gmail.com',
        mobileNo: '8379882933',
        subject: 'Biology,Chemistry',
        questionAsk: '2',
        balance: '300',
    },
    {
        id: 2,
        date: '21/02/23',
        username: 'Abernathy Group',
        email: 'Eliseo@gardner.biz',
        mobileNo: '9679882933',
        subject: 'Chemistry',
        questionAsk: '3',
        balance: '500',
    },
    {
        id: 3,
        date: '12/02/23',
        username: 'Eknath Raut',
        email: 'Jayne_Kuhic@sydney.com',
        mobileNo: '7779882933',
        subject: 'Biology,math',
        questionAsk: '2',
        balance: '600',
    },
    {
        id: 4,
        date: '21/02/23',
        username: 'Eknath Raut',
        email: 'Nikita@garfield.biz',
        mobileNo: '9879882933',
        subject: 'Chemistry,physics',
        questionAsk: '2',
        balance: '600',
    },
    {
        id: 5,
        date: '12/02/23',
        username: 'Eknath Raut',
        email: 'Lew@alysha.tv',
        mobileNo: '8879882933',
        subject: 'Math,biology',
        questionAsk: '5',
        balance: '700',
    },
    {
        id: 6,
        date: '16/02/23',
        username: 'Eknath Raut',
        email: 'Hayden@althea.biz',
        mobileNo: '9679882933',
        subject: 'Biology',
        questionAsk: '5',
        balance: '500',
    },
    {
        id: 7,
        date: '18/02/23',
        username: 'Clementine Bauch',
        email: 'Mallory_Kunze@marie.org',
        mobileNo: '7879882933',
        subject: 'Chemistry',
        questionAsk: '5',
        balance: '400',
    },
    {
        id: 8,
        date: '26/02/23',
        username: 'Kurtis Weissnat',
        email: 'Kariane@jadyn.tv',
        mobileNo: '9879882933',
        subject: 'Physics,thermodynamics',
        questionAsk: '5',
        balance: '700',
    },
    {
        id: 9,
        date: '18/02/23',
        username: 'Ellsworth Summit',
        email: 'Preston_Hudson@blaise.tv',
        mobileNo: '8779882933',
        subject: 'Biology',
        questionAsk: '2',
        balance: '100',
    },
    {
        id: 10,
        date: '20/02/23',
        username: 'Ervin Howell',
        email: 'eknathraut09@gmail.com',
        mobileNo: '8979882933',
        subject: 'Physics,botany',
        questionAsk: '2',
        balance: '250',
    }
]