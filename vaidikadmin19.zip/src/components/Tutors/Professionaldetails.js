import React, { useState } from "react";
import Footer from "../shared/Footer";
import Navbar from "../shared/Navbar";
import Sidebar from "../shared/Sidebar";
import "../Css/Tutorlist.css";
import Form from 'react-bootstrap/Form';
import Button from "@mui/material/Button";
import FloatingLabel from 'react-bootstrap/FloatingLabel';
import { Label } from "reactstrap";

const Professionaldetails = () => {

  //  for profile-image
  const [myimage, setMyImage] = useState(null);
  const uploadImage = (e) => {
    setMyImage(URL.createObjectURL(e.target.files[0]));
  }

  return (
    <div>
      <div className="container-scroller">
        <Navbar />
        <div className="container-fluid page-body-wrapper">
          <Sidebar />
          <div className="main-panel">
            <div className="content-wrapper">
              <div className="page-header">
                <h3 className="page-title">
                  Professional Details
                </h3>
              </div>
              <div className="row">
                <div className="col-12 grid-margin stretch-card">
                  <div className="card">
                    <div className="card-body">
                      <div className="profile-details">
                        <img src={myimage} className="profile-img" alt="" />
                        <div className="">
                          <Button
                            variant="contained"
                            component="label"
                            className="mx-3 text-white"
                            size="small"
                          >
                            Upload
                            <input
                              hidden
                              accept="image/*"
                              type="file"
                              onChange={uploadImage}
                            />
                          </Button>
                          <Button variant="contained" size="small">
                            Reset
                          </Button>
                          <div>
                            <small className="text-muted d-flex flex-column my-3 mx-3">
                              Allowed JPG,GIf or PNG. Max size of 800K
                            </small>
                          </div>
                        </div>
                      </div>
                      <Form>
                        <div className="row">
                          <div className="col-md-6">
                            <Form.Group className="mb-3" controlId="formBasicEmail">
                              <Form.Label>Name</Form.Label>
                              <Form.Control type="email" placeholder="Enter Name" />
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="formBasicEmail">
                              <Form.Label>Mobile No.</Form.Label>
                              <Form.Control type="email" placeholder="Enter Number" />
                            </Form.Group>
                          </div>
                          <div className="col-md-6">
                            <Form.Group className="mb-3" controlId="formBasicEmail">
                              <Form.Label>Email Id</Form.Label>
                              <Form.Control type="email" placeholder="Enter Email" />
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="formBasicEmail">
                              <Form.Label>Screen Name</Form.Label>
                              <Form.Control type="email" placeholder="Enter Name" />
                            </Form.Group>
                          </div>
                        </div>
                        <div className="row">
                          <div className="col-md-4">
                            <Label>Country</Label>
                            <Form.Select>
                              <option>India</option>
                              <option value="1">Canada</option>
                              <option value="2">London</option>
                              <option value="3">Australia</option>
                            </Form.Select>
                          </div>
                          <div className="col-md-4">
                            <Label>State</Label>
                            <Form.Select>
                              <option>Gujarat</option>
                              <option value="1">Delhi</option>
                              <option value="2">Mp</option>
                              <option value="3">Bihar</option>
                            </Form.Select>
                          </div>
                          <div className="col-md-4">
                            <Label>City</Label>
                            <Form.Select>
                              <option>Surat</option>
                              <option value="1">Ahmedabad</option>
                              <option value="2">Rajkot</option>
                              <option value="3">Baroda</option>
                            </Form.Select>
                          </div>
                        </div>
                        <div className="row mt-4">
                          <div className="col-md-6">
                            <FloatingLabel controlId="floatingTextarea2" label="Address">
                              <Form.Control
                                as="textarea"
                                placeholder="Leave a comment here"
                                style={{ height: '80px' }}
                              />
                            </FloatingLabel>
                          </div>
                          <div className="col-md-6">
                            <Form.Group className="mb-3" controlId="formBasicEmail">
                              <Form.Label>Time Zone</Form.Label>
                              <Form.Control type="email" placeholder="Enter Time Zone" />
                            </Form.Group>
                          </div>
                        </div>
                      </Form>
                    </div>
                  </div>
                </div>
                <div className="col-12 grid-margin stretch-card">
                  <div className="card">
                    <div className="card-body">
                      <Form>
                        <div className="row">
                          <div className="col-md-6">
                            <Form.Group className="mb-3" controlId="formBasicEmail">
                              <Form.Label>Name</Form.Label>
                              <Form.Control type="email" placeholder="Enter Name" />
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="formBasicEmail">
                              <Form.Label>Mobile No.</Form.Label>
                              <Form.Control type="email" placeholder="Enter Number" />
                            </Form.Group>
                          </div>
                          <div className="col-md-6">
                            <Form.Group className="mb-3" controlId="formBasicEmail">
                              <Form.Label>Email Id</Form.Label>
                              <Form.Control type="email" placeholder="Enter Email" />
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="formBasicEmail">
                              <Form.Label>Screen Name</Form.Label>
                              <Form.Control type="email" placeholder="Enter Name" />
                            </Form.Group>
                          </div>
                        </div>
                        <div className="row">
                          <div className="col-md-4">
                            <Label>Country</Label>
                            <Form.Select>
                              <option>India</option>
                              <option value="1">Canada</option>
                              <option value="2">London</option>
                              <option value="3">Australia</option>
                            </Form.Select>
                          </div>
                          <div className="col-md-4">
                            <Label>State</Label>
                            <Form.Select>
                              <option>Gujarat</option>
                              <option value="1">Delhi</option>
                              <option value="2">Mp</option>
                              <option value="3">Bihar</option>
                            </Form.Select>
                          </div>
                          <div className="col-md-4">
                            <Label>City</Label>
                            <Form.Select>
                              <option>Surat</option>
                              <option value="1">Ahmedabad</option>
                              <option value="2">Rajkot</option>
                              <option value="3">Baroda</option>
                            </Form.Select>
                          </div>
                        </div>
                        <div className="row mt-4">
                          <div className="col-md-6">
                            <FloatingLabel controlId="floatingTextarea2" label="Address">
                              <Form.Control
                                as="textarea"
                                placeholder="Leave a comment here"
                                style={{ height: '80px' }}
                              />
                            </FloatingLabel>
                          </div>
                          <div className="col-md-6">
                            <Form.Group className="mb-3" controlId="formBasicEmail">
                              <Form.Label>Time Zone</Form.Label>
                              <Form.Control type="email" placeholder="Enter Time Zone" />
                            </Form.Group>
                          </div>
                        </div>
                      </Form>
                    </div>
                  </div>
                </div>
                <div className="col-12 grid-margin stretch-card">
                  <div className="card">
                    <div className="card-body">
                      <div className="page-header">
                        <h3 className="page-title">
                          Bank Detais
                        </h3>
                      </div>
                      <Form>
                        <div className="row">
                          <div className="col-md-6">
                            <Form.Group className="mb-3" controlId="formBasicEmail">
                              <Form.Label>Name</Form.Label>
                              <Form.Control type="email" placeholder="Enter Name" />
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="formBasicEmail">
                              <Form.Label>IFSC Code</Form.Label>
                              <Form.Control type="email" placeholder="Enter IFSC Code" />
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="formBasicEmail">
                              <Form.Label>Pan Card</Form.Label>
                              <Form.Control type="email" placeholder="Enter Pan Card Number" />
                            </Form.Group>
                          </div>
                          <div className="col-md-6">
                            <Form.Group className="mb-3" controlId="formBasicEmail">
                              <Form.Label>Account Number</Form.Label>
                              <Form.Control type="email" placeholder="Enter Account Number" />
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="formBasicEmail">
                              <Form.Label>Account Type</Form.Label>
                              <Form.Control type="email" placeholder="Enter Account Type" />
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="formBasicEmail">
                              <Form.Label>Bank Name</Form.Label>
                              <Form.Control type="email" placeholder="Enter Bank Name" />
                            </Form.Group>
                          </div>
                        </div>
                      </Form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <Footer />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Professionaldetails;
